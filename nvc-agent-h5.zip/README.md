# NVC Agent - 非暴力沟通助手

基于非暴力沟通（NVC）理念的 AI 沟通助手，帮助情侣在争执后更好地理解自己和伴侣。

## 功能

- 📷 **截图分析**：上传聊天截图，AI 识别情绪强烈的语句
- 💬 **文字输入**：手动输入聊天内容进行分析
- 😊 **情绪确认**：用表情包确认自己和伴侣的感受
- 📊 **情绪报告**：可视化情绪分布分析
- 🎯 **需求明确**：找到争执背后的核心需求
- 📝 **沟通报告**：生成 NVC 沟通建议报告

## 技术栈

- 纯 HTML + CSS + JavaScript（无框架依赖）
- AI 服务：Amux AI API
- 响应式设计，适配移动端

## 使用方法

### 本地运行

直接双击 `index.html` 文件即可在浏览器中打开使用。

### GitHub Pages 部署

本项目已配置为支持 GitHub Pages 部署：

1. 创建 GitHub 仓库
2. 将代码推送到仓库的 `main` 分支
3. 在仓库设置中启用 GitHub Pages，选择 `main` 分支作为源

## 项目结构

```
.
├── index.html          # 主页面（包含所有逻辑）
├── README.md           # 项目说明
└── memes/              # 表情包图片资源
    ├── annoyed_irritated.png
    ├── astonished_shocked.png
    └── ...
```

## License

MIT
